"""Top-level package for RP Tree."""

__version__ = "0.1.1"
