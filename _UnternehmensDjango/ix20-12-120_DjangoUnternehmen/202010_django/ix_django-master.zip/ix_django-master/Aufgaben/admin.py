from django.contrib import admin

from .models import Liste, Status

# Register your models here.

admin.site.register(Liste)
admin.site.register(Status)