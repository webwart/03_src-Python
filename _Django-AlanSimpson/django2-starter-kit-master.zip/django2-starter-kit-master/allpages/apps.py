from django.apps import AppConfig


class AllpagesConfig(AppConfig):
    name = 'allpages'
